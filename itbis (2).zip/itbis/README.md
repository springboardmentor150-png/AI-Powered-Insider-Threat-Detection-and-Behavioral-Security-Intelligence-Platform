# ITBIS — Milestone 1: Setup & Run Guide

This project is fully coded for Milestone 1 (auth, roles, employee CRUD,
log ingestion). Follow these steps on your own machine — installs and
database setup can't be run for you, since they need your local network
and OS.

## 0. Prerequisites (install once)

- Python 3.10+
- Node.js 18+
- PostgreSQL running locally (or a free hosted instance, e.g. Neon, Supabase)
- MongoDB running locally (or a free Atlas cluster)
- Git

## 1. Get the project onto your machine

Unzip the folder you downloaded, or if you're pushing to your own repo:

```bash
cd itbis
git init
git add .
git commit -m "Initial project setup"
git checkout -b your-name-branch
git remote add origin <your-repo-url>
git push -u origin your-name-branch
```

## 2. Backend setup

```bash
cd backend
python -m venv venv

# activate it:
venv\Scripts\activate       # Windows
source venv/bin/activate    # Mac/Linux

pip install -r requirements.txt
```

### Configure environment variables

```bash
cp .env.example .env        # Mac/Linux
copy .env.example .env      # Windows
```

Open `.env` and fill in your real PostgreSQL and MongoDB connection strings.
If both databases are running locally with defaults, the example values
will mostly work as-is — just make sure the PostgreSQL user/password/db
name actually exist. To create them:

```sql
-- run inside psql
CREATE DATABASE itbis_db;
CREATE USER itbis_user WITH PASSWORD 'itbis_pass';
GRANT ALL PRIVILEGES ON DATABASE itbis_db TO itbis_user;
```

MongoDB needs no setup — `pymongo` creates the `itbis` database and its
collections automatically the first time you insert a document.

### Run the backend

```bash
uvicorn app.main:app --reload
```

Visit **http://127.0.0.1:8000/docs** — this is FastAPI's interactive
Swagger UI. You can test every endpoint here without touching the frontend.

You should see `{"status": "ITBIS backend is running"}` at
http://127.0.0.1:8000/.

## 3. Frontend setup

The frontend code (pages, API client, styles) is already written for you
under `frontend/`. You just need to install its dependencies:

```bash
cd ../frontend
npm install
npm run dev
```

Visit **http://localhost:3000**.

> Note: `package.json` is already set up so `npm install` pulls in Next.js,
> React, and axios — you don't need to run `create-next-app` again.

## 4. Test the full flow end-to-end

1. **Create a user.** Easiest via Swagger docs (`/docs` → `POST /auth/signup`):
   ```json
   {
     "email": "admin@itbis.com",
     "password": "SuperSecret123",
     "role": "admin"
   }
   ```
2. **Log in.** In the browser go to `http://localhost:3000/login` and sign
   in with that email/password. This calls `POST /auth/login`, gets a JWT
   back, and saves it in `localStorage`.
3. **Create an employee.** Go to `http://localhost:3000/employees` and use
   the "Onboard Employee" form. This calls `POST /employees` with your JWT
   attached automatically.
4. **Test role restriction.** Create a second user with
   `"role": "security_analyst"`, log in as them, and confirm they can
   view employees (`GET /employees`) but get a `403 Forbidden` if they try
   to hit `DELETE /employees/{id}` — analysts aren't in that endpoint's
   allowed-roles list.
5. **Ingest a sample activity log.** Via `/docs`, call `POST /logs/ingest`:
   ```json
   {
     "employee_id": "EMP1001",
     "event_type": "login",
     "details": { "ip_address": "192.168.1.10", "device": "laptop-01" }
   }
   ```
   Then confirm it's stored by calling `GET /logs/EMP1001`.

## 5. Where each Milestone 1 requirement lives in the code

| Requirement                          | File(s) |
|---------------------------------------|---------|
| Architecture / schema                 | this README + `models.py`, `database.py` |
| FastAPI + CORS running                | `app/main.py` |
| Password hashing                      | `app/models.py` (`hash_password`, `verify_password`) |
| JWT issue/verify                      | `app/auth.py` |
| Role-based access control             | `app/auth.py` (`require_role`), used in `routes/employees.py` and `routes/logs.py` |
| Employee CRUD                         | `app/routes/employees.py` |
| Activity log ingestion (MongoDB)      | `app/routes/logs.py`, `app/database.py` |
| Next.js frontend + login + employee UI| `frontend/pages/*.js` |

## 6. Self-check before demo (from the handout)

- [ ] Backend and frontend both run locally without errors
- [ ] CORS configured (already done in `main.py`)
- [ ] Signup/login work; passwords are hashed (check the `users` table — you should see a long bcrypt string, never plain text)
- [ ] JWT required on protected endpoints (try calling `/employees` from `/docs` without clicking "Authorize" first — it should fail)
- [ ] At least 2 roles tested against different endpoints
- [ ] Employee CRUD endpoints all work
- [ ] Sample logs ingest and are visible (check with `GET /logs/{employee_id}`, or open MongoDB Compass and look at the `itbis.activity_logs` collection)
- [ ] Code committed and pushed to your branch

## Common issues

- **"Connection refused" on PostgreSQL/MongoDB** → the database service isn't running locally. Start it (e.g. `pg_ctl start`, `mongod`, or your OS's service manager / Docker container).
- **CORS errors in the browser console** → double check the frontend is actually running on port 3000; `main.py` only allows that origin.
- **401 on every request in the frontend** → you're not logged in yet, or `localStorage` doesn't have a token (log in first at `/login`).
- **403 on an endpoint** → working as intended — that's the role check firing. Log in as a role that's allowed.
