"""
schemas.py
----------
Pydantic models define the SHAPE of data coming in and going out of the API.
They're different from the SQLAlchemy models in models.py:
  - models.py    -> how data is stored in the database
  - schemas.py   -> how data looks in an HTTP request/response

FastAPI uses these to auto-validate incoming JSON (reject bad requests
before your function code even runs) and to auto-generate the /docs page.
"""

from pydantic import BaseModel, EmailStr
from datetime import datetime
from typing import Optional, Any


# ---------- Auth ----------
class UserCreate(BaseModel):
    email: EmailStr
    password: str
    role: str  # "security_analyst" | "soc_engineer" | "security_manager" | "admin"


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    id: int
    email: EmailStr
    role: str

    class Config:
        from_attributes = True  # lets this read straight from a SQLAlchemy object


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


# ---------- Employees ----------
class EmployeeCreate(BaseModel):
    employee_id: str
    name: str
    department: str
    designation: str
    manager_id: Optional[int] = None
    device_info: Optional[str] = None
    access_privileges: Optional[str] = None


class EmployeeUpdate(BaseModel):
    name: Optional[str] = None
    department: Optional[str] = None
    designation: Optional[str] = None
    manager_id: Optional[int] = None
    device_info: Optional[str] = None
    access_privileges: Optional[str] = None


class EmployeeOut(BaseModel):
    id: int
    employee_id: str
    name: str
    department: str
    designation: str
    manager_id: Optional[int]
    device_info: Optional[str]
    access_privileges: Optional[str]

    class Config:
        from_attributes = True


# ---------- Activity logs (MongoDB, so no fixed table) ----------
class LogIngest(BaseModel):
    employee_id: str
    event_type: str          # e.g. "login", "file_download", "usb_connect"
    details: dict[str, Any]  # shape varies per event_type - that's the point


class LogOut(BaseModel):
    employee_id: str
    event_type: str
    timestamp: datetime
    details: dict[str, Any]
