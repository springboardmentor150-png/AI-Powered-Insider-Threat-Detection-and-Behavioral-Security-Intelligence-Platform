"""
database.py
------------
Sets up connections to BOTH databases the project uses:
  - PostgreSQL (via SQLAlchemy) for structured data: users, employees, incidents, alerts
  - MongoDB (via PyMongo) for flexible data: activity_logs, behavioral_baselines

Every other file that needs a database talks to it through what's defined here,
so there's only one place to update if a connection string ever changes.
"""

import os
from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from pymongo import MongoClient

# Load variables from a .env file (copy .env.example to .env first)
load_dotenv()

# ---------- PostgreSQL (SQLAlchemy) ----------
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://itbis_user:itbis_pass@localhost:5432/itbis_db")

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# All SQLAlchemy models (in models.py) inherit from this Base
Base = declarative_base()


def get_db():
    """
    FastAPI dependency that hands each request its own database session
    and guarantees it gets closed afterward, even if an error occurs.
    Use it like: def my_route(db: Session = Depends(get_db)):
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ---------- MongoDB (PyMongo) ----------
MONGO_URL = os.getenv("MONGO_URL", "mongodb://localhost:27017")
MONGO_DB_NAME = os.getenv("MONGO_DB_NAME", "itbis")

mongo_client = MongoClient(MONGO_URL)
mongo_db = mongo_client[MONGO_DB_NAME]

# Collections used in this milestone
activity_logs_collection = mongo_db["activity_logs"]
behavioral_baselines_collection = mongo_db["behavioral_baselines"]
