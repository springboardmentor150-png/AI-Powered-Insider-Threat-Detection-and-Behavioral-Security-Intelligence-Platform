"""
auth.py
-------
Everything related to proving WHO is calling the API (authentication)
and WHAT they're allowed to do (role-based authorization).

Flow:
  1. User logs in with email+password -> create_token() issues a JWT.
  2. Every protected request sends that JWT in the Authorization header.
  3. get_current_user() decodes it and loads the user.
  4. require_role(...) further checks the user's role before letting
     the request reach the actual endpoint logic.
"""

import os
from datetime import datetime, timedelta
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import jwt, JWTError
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import User

SECRET_KEY = os.getenv("SECRET_KEY", "change-this-in-production")
ALGORITHM = os.getenv("ALGORITHM", "HS256")
ACCESS_TOKEN_EXPIRE_HOURS = int(os.getenv("ACCESS_TOKEN_EXPIRE_HOURS", "8"))

# Tells FastAPI's auto-docs where to send login requests to get a token.
# tokenUrl points at the login endpoint defined in routes/auth.py
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")


def create_token(user_id: int, role: str) -> str:
    """Builds a signed, tamper-proof JWT carrying the user's id and role."""
    payload = {
        "sub": str(user_id),
        "role": role,
        "exp": datetime.utcnow() + timedelta(hours=ACCESS_TOKEN_EXPIRE_HOURS),
    }
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def decode_token(token: str) -> dict:
    """Verifies the signature and expiry, then returns the payload."""
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        )


def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    """
    Dependency for any endpoint that just needs to know "who is logged in?"
    without caring about their specific role.
    """
    payload = decode_token(token)
    user_id = int(payload["sub"])
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=401, detail="User no longer exists")
    return user


def require_role(*allowed_roles: str):
    """
    Dependency FACTORY. Call it with the roles that should be allowed through,
    and it returns a dependency you can drop onto any route:

        @router.get("/admin/users")
        def list_users(user = Depends(require_role("admin"))):
            ...

    If the caller's role isn't in allowed_roles, the request is blocked
    with a 403 before your endpoint code ever runs.
    """
    def checker(current_user: User = Depends(get_current_user)) -> User:
        if current_user.role not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Role '{current_user.role}' is not authorized for this action",
            )
        return current_user
    return checker
