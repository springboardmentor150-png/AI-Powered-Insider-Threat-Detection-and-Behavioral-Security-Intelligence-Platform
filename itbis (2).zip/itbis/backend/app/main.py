"""
main.py
-------
The entrypoint. This is what `uvicorn app.main:app --reload` runs.
It creates the FastAPI app, sets up CORS, creates PostgreSQL tables
if they don't exist yet, and wires in all the route modules.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import engine, Base
from app.routes import auth_routes, employees, logs

# This line reads every model in models.py (because auth_routes/employees
# import from app.models indirectly) and creates any missing tables in
# PostgreSQL. Safe to run every time - it won't touch tables that already exist.
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="ITBIS API",
    description="Insider Threat Behavioral Intelligence System - Milestone 1",
    version="0.1.0",
)

# Required from day one: frontend (port 3000) and backend (port 8000) are
# different origins, so without this the browser blocks the frontend's
# requests to the API.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_routes.router)
app.include_router(employees.router)
app.include_router(logs.router)


@app.get("/")
def health_check():
    return {"status": "ITBIS backend is running"}
