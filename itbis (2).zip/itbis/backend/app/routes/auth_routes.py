"""
routes/auth_routes.py
----------------------
Signup and login endpoints. These are the only two endpoints in the whole
app that DON'T require a token, since you need to log in before you have one.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import User, hash_password, verify_password
from app.schemas import UserCreate, UserLogin, UserOut, Token
from app.auth import create_token

router = APIRouter(prefix="/auth", tags=["Auth"])

VALID_ROLES = {"security_analyst", "soc_engineer", "security_manager", "admin"}


@router.post("/signup", response_model=UserOut)
def signup(data: UserCreate, db: Session = Depends(get_db)):
    if data.role not in VALID_ROLES:
        raise HTTPException(status_code=400, detail=f"Role must be one of {VALID_ROLES}")

    existing = db.query(User).filter(User.email == data.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    user = User(
        email=data.email,
        password_hash=hash_password(data.password),
        role=data.role,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@router.post("/login", response_model=Token)
def login(data: UserLogin, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == data.email).first()

    # Deliberately vague error message - don't reveal whether the email
    # exists or the password was wrong. That distinction helps attackers.
    if not user or not verify_password(data.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    token = create_token(user_id=user.id, role=user.role)
    return Token(access_token=token)
