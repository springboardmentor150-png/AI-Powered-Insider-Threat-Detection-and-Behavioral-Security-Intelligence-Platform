"""
routes/logs.py
--------------
Accepts and stores raw activity log events in MongoDB. This milestone
doesn't connect to real log sources (AD, VPN, firewalls) - it just builds
the pipeline and lets you test it with sample/mock data via /docs or Postman.
"""

from fastapi import APIRouter, Depends, HTTPException
from datetime import datetime
from typing import List

from app.database import activity_logs_collection
from app.schemas import LogIngest, LogOut
from app.auth import require_role

router = APIRouter(prefix="/logs", tags=["Activity Logs"])


@router.post("/ingest")
def ingest_log(
    data: LogIngest,
    user=Depends(require_role("admin", "security_manager", "security_analyst", "soc_engineer")),
):
    log_entry = {
        "employee_id": data.employee_id,
        "event_type": data.event_type,
        "timestamp": datetime.utcnow(),
        "details": data.details,
    }
    result = activity_logs_collection.insert_one(log_entry)
    return {
        "message": "Log ingested",
        "id": str(result.inserted_id),
        "event_type": data.event_type,
    }


@router.get("/{employee_id}", response_model=List[LogOut])
def get_logs_for_employee(
    employee_id: str,
    limit: int = 50,
    user=Depends(require_role("admin", "security_manager", "security_analyst", "soc_engineer")),
):
    """Returns the most recent activity logs for one employee, newest first."""
    cursor = (
        activity_logs_collection.find({"employee_id": employee_id})
        .sort("timestamp", -1)
        .limit(limit)
    )
    logs = list(cursor)
    if not logs:
        raise HTTPException(status_code=404, detail="No logs found for this employee")
    return logs
