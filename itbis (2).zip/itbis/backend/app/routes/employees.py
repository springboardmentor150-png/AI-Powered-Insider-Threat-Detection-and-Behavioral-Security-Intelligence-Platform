"""
routes/employees.py
--------------------
CRUD endpoints for employee profiles - the people ITBIS monitors
(not the same as "users", who are the analysts logging into the platform).

Notice each route has a DIFFERENT allowed-roles list:
  - only admins/managers can create or delete employees
  - analysts and SOC engineers can read employee data, but not create/delete it
This is what "role-based access control" means in practice.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app.models import Employee
from app.schemas import EmployeeCreate, EmployeeUpdate, EmployeeOut
from app.auth import require_role

router = APIRouter(prefix="/employees", tags=["Employees"])


@router.post("", response_model=EmployeeOut)
def create_employee(
    data: EmployeeCreate,
    db: Session = Depends(get_db),
    user=Depends(require_role("admin", "security_manager")),
):
    existing = db.query(Employee).filter(Employee.employee_id == data.employee_id).first()
    if existing:
        raise HTTPException(status_code=400, detail="employee_id already exists")

    employee = Employee(**data.model_dump())
    db.add(employee)
    db.commit()
    db.refresh(employee)
    return employee


@router.get("", response_model=List[EmployeeOut])
def list_employees(
    db: Session = Depends(get_db),
    user=Depends(require_role("admin", "security_manager", "security_analyst", "soc_engineer")),
):
    return db.query(Employee).all()


@router.get("/{employee_id}", response_model=EmployeeOut)
def get_employee(
    employee_id: str,
    db: Session = Depends(get_db),
    user=Depends(require_role("admin", "security_manager", "security_analyst", "soc_engineer")),
):
    employee = db.query(Employee).filter(Employee.employee_id == employee_id).first()
    if not employee:
        raise HTTPException(status_code=404, detail="Employee not found")
    return employee


@router.put("/{employee_id}", response_model=EmployeeOut)
def update_employee(
    employee_id: str,
    data: EmployeeUpdate,
    db: Session = Depends(get_db),
    user=Depends(require_role("admin", "security_manager")),
):
    employee = db.query(Employee).filter(Employee.employee_id == employee_id).first()
    if not employee:
        raise HTTPException(status_code=404, detail="Employee not found")

    for field, value in data.model_dump(exclude_unset=True).items():
        setattr(employee, field, value)

    db.commit()
    db.refresh(employee)
    return employee


@router.delete("/{employee_id}")
def delete_employee(
    employee_id: str,
    db: Session = Depends(get_db),
    user=Depends(require_role("admin")),
):
    employee = db.query(Employee).filter(Employee.employee_id == employee_id).first()
    if not employee:
        raise HTTPException(status_code=404, detail="Employee not found")

    db.delete(employee)
    db.commit()
    return {"message": f"Employee {employee_id} deleted"}
