"""
models.py
---------
SQLAlchemy ORM models = the Python classes that map directly onto your
PostgreSQL tables. Each class attribute becomes a column.

These four tables come straight from the handout's schema:
  users, employees, incidents, alerts
"""

from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.sql import func
from passlib.context import CryptContext

from app.database import Base

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
    """Scrambles a plaintext password one-way before saving it."""
    return pwd_context.hash(password)


def verify_password(plain: str, hashed: str) -> bool:
    """Checks a login attempt against the stored hash without ever un-scrambling it."""
    return pwd_context.verify(plain, hashed)


class User(Base):
    """
    Platform users: the people who LOG IN to ITBIS itself
    (security analysts, SOC engineers, security managers, admins).
    """
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=False)
    role = Column(String, nullable=False)
    # allowed roles: "security_analyst", "soc_engineer", "security_manager", "admin"
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Employee(Base):
    """
    Employees: the people ITBIS MONITORS. They never log into the platform;
    their workplace activity is what gets tracked and analyzed.
    """
    __tablename__ = "employees"

    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(String, unique=True, index=True, nullable=False)
    name = Column(String, nullable=False)
    department = Column(String, nullable=False)
    designation = Column(String, nullable=False)
    manager_id = Column(Integer, nullable=True)
    device_info = Column(String, nullable=True)
    access_privileges = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Incident(Base):
    """
    A confirmed or suspected insider-threat incident tied to one employee.
    Populated later (Milestone 2+ will feed this from anomaly detection);
    for now it just needs to exist and be creatable manually.
    """
    __tablename__ = "incidents"

    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(String, ForeignKey("employees.employee_id"), nullable=False)
    status = Column(String, default="open")       # open, investigating, closed
    severity = Column(String, default="low")      # low, medium, high, critical
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Alert(Base):
    """
    A single alert notification tied to an employee, e.g. from a rule firing.
    """
    __tablename__ = "alerts"

    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(String, ForeignKey("employees.employee_id"), nullable=False)
    severity = Column(String, default="low")
    message = Column(String, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
