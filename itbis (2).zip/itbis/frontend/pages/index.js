import { useEffect, useState } from "react";
import Link from "next/link";
import api from "../lib/api";

export default function Home() {
  const [status, setStatus] = useState("checking...");

  useEffect(() => {
    api
      .get("/")
      .then((res) => setStatus(res.data.status))
      .catch(() => setStatus("backend unreachable - is uvicorn running?"));
  }, []);

  return (
    <div>
      <h1>ITBIS</h1>
      <p>Backend status: <strong>{status}</strong></p>
      <nav style={{ display: "flex", gap: "1rem" }}>
        <Link href="/login">Login</Link>
        <Link href="/employees">Employees</Link>
      </nav>
    </div>
  );
}
