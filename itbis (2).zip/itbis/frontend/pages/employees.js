import { useEffect, useState } from "react";
import api from "../lib/api";

export default function Employees() {
  const [employees, setEmployees] = useState([]);
  const [error, setError] = useState("");
  const [form, setForm] = useState({
    employee_id: "",
    name: "",
    department: "",
    designation: "",
  });

  async function loadEmployees() {
    setError("");
    try {
      const res = await api.get("/employees");
      setEmployees(res.data);
    } catch (err) {
      setError(err.response?.data?.detail || "Could not load employees. Are you logged in?");
    }
  }

  useEffect(() => {
    loadEmployees();
  }, []);

  async function handleCreate(e) {
    e.preventDefault();
    setError("");
    try {
      await api.post("/employees", form);
      setForm({ employee_id: "", name: "", department: "", designation: "" });
      loadEmployees();
    } catch (err) {
      setError(err.response?.data?.detail || "Could not create employee");
    }
  }

  return (
    <div>
      <h1>Employees</h1>

      <form onSubmit={handleCreate} className="card">
        <h3>Onboard Employee</h3>
        {["employee_id", "name", "department", "designation"].map((field) => (
          <div key={field}>
            <input
              placeholder={field}
              value={form[field]}
              onChange={(e) => setForm({ ...form, [field]: e.target.value })}
              required
              style={{ width: "100%" }}
            />
          </div>
        ))}
        <button type="submit">Create</button>
      </form>

      {error && <p className="error">{error}</p>}

      <table>
        <thead>
          <tr>
            <th>Employee ID</th>
            <th>Name</th>
            <th>Department</th>
            <th>Designation</th>
          </tr>
        </thead>
        <tbody>
          {employees.map((emp) => (
            <tr key={emp.id}>
              <td>{emp.employee_id}</td>
              <td>{emp.name}</td>
              <td>{emp.department}</td>
              <td>{emp.designation}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
