import { useState } from "react";
import { useRouter } from "next/router";
import api from "../lib/api";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const router = useRouter();

  async function handleLogin(e) {
    e.preventDefault();
    setError("");
    try {
      const res = await api.post("/auth/login", { email, password });
      // Save the JWT so lib/api.js can attach it to future requests.
      localStorage.setItem("itbis_token", res.data.access_token);
      router.push("/employees");
    } catch (err) {
      setError(err.response?.data?.detail || "Login failed");
    }
  }

  return (
    <div className="card">
      <h1>Log In</h1>
      <form onSubmit={handleLogin}>
        <div>
          <label>Email</label><br />
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            style={{ width: "100%" }}
          />
        </div>
        <div>
          <label>Password</label><br />
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            style={{ width: "100%" }}
          />
        </div>
        {error && <p className="error">{error}</p>}
        <button type="submit">Log In</button>
      </form>
      <p style={{ fontSize: "0.85rem", opacity: 0.7 }}>
        No account? Use the <code>/auth/signup</code> endpoint in the API docs
        (http://127.0.0.1:8000/docs) to create one for now - a signup page
        can be added as a later enhancement.
      </p>
    </div>
  );
}
